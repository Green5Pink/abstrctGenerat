import os

dirname = __path__[0]
__path__.insert(0, os.path.join(dirname, "summa"))